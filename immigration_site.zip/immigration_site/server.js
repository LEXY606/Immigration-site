// server.js
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
app.use(express.json());
const LEADS_FILE = path.join(__dirname, 'leads.json');

function saveLead(lead){
  let list = [];
  if (fs.existsSync(LEADS_FILE)) {
    try { list = JSON.parse(fs.readFileSync(LEADS_FILE,'utf8') || '[]'); } catch(e){ list = []; }
  }
  lead.id = Date.now();
  list.push(lead);
  fs.writeFileSync(LEADS_FILE, JSON.stringify(list, null, 2));
}

app.post('/api/leads', (req, res) => {
  const { name, email, service, message } = req.body;
  if (!name || !email) return res.status(400).json({ error: 'Name and contact required' });
  saveLead({ name, email, service, message, createdAt: new Date().toISOString() });
  // In production: send notification/email here
  res.json({ ok: true });
});

app.get('/admin/leads', (req,res) => {
  // Simple admin endpoint - PROTECT this in production with authentication
  if (!fs.existsSync(LEADS_FILE)) return res.json([]);
  res.json(JSON.parse(fs.readFileSync(LEADS_FILE,'utf8')));
});

// Serve static files (index.html)
app.use('/', express.static(__dirname));

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server running on port', PORT));
