Immigration Site Starter
========================

What's included:
- index.html : static homepage with a contact form.
- server.js  : simple Express server that accepts /api/leads POST and saves to leads.json.
- package.json : Node project file.
- leads.json : where submitted leads are stored (starts empty).

How to run locally:
1. Ensure you have Node.js (>=14) installed.
2. In a terminal, cd to the project folder:
   cd immigration_site
3. Install dependencies:
   npm install
4. Start the server:
   npm start
5. Open http://localhost:3000 in your browser.

Notes & next steps:
- The /admin/leads endpoint returns stored leads as JSON. Protect it with authentication before using publicly.
- For production, use a real database (Postgres, Mongo, or managed DB) and add HTTPS, backups.
- To accept payments or bookings, integrate Stripe or Paystack and a scheduling widget.
- I can customize branding, content, or convert this to WordPress/Next.js + Strapi if you want.
